import React from "react";
import "./Navbar.css";

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-brand">Brand</div>
        <ul className="navbar-menu">
          <li className="navbar-item">
            <a href="#">Home</a>
            <ul className="dropdown-menu">
              <li><a href="#overview">Overview</a></li>
              <li><a href="#updates">Updates</a></li>
              <li><a href="#team">Team</a></li>
            </ul>
          </li>
          <li className="navbar-item">
            <a href="#">About</a>
            <ul className="dropdown-menu">
              <li><a href="#history">History</a></li>
              <li><a href="#mission">Mission</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </li>
          <li className="navbar-item">
            <a href="#">Services</a>
            <ul className="dropdown-menu">
              <li><a href="#design">Design</a></li>
              <li><a href="#development">Development</a></li>
              <li><a href="#marketing">Marketing</a></li>
            </ul>
          </li>
          <li className="navbar-item">
            <a href="#">Blog</a>
            <ul className="dropdown-menu">
              <li><a href="#latest">Latest Posts</a></li>
              <li><a href="#trending">Trending</a></li>
              <li><a href="#archive">Archive</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
