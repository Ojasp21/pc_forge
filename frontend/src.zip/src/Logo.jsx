import './Logo.css'
export default function Logo () {
    return (
        <a className="href">PC Forge</a>
    )
}