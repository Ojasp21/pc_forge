import './BuildButton.css'
export default function BuildButton () {
    return (

        <a href="#" className='btn'>
            <button class="build-btn">Build Your PC</button>
        </a>

    );
}