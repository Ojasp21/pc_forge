import { useState } from 'react'
import './App.css'
import Navbar from './Navbar'
import backgroundImage from './pc5.png'
import './bgImage.css'
import BuildButton from './BuildButton'
import Allcards from './Allcards'

function App() {

  return (
    <>
    <div className='App'>
      <Navbar/>
    </div>
    <div className='bg-image' style={{backgroundImage: `URL(${backgroundImage})`}}>    
    </div>
    <div className='' style={{minHeight:"110vh"}}>
      <BuildButton />
    </div>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <div className="app-container">
   <Allcards/>
  </div>
    </>
  )
}

export default App
