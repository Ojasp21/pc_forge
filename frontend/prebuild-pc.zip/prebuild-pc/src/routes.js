// src/routes.js

import GamingPC from "./components/GamingPC";
import ProfessionalPC from "./components/ProfessionalPC";
import EditingPC from "./components/EditingPC";
import GamingContainer1 from "./components/containers/GamingContainer1";
import GamingContainer2 from "./components/containers/GamingContainer2";
import ProfContainer1 from "./components/containers/ProfContainer1";
import ProfContainer2 from "./components/containers/ProfContainer2";
import PrebuildPCPage from "./components/PreBuildPCPage";

export const routes = [
  { path: "/", element: <PrebuildPCPage /> },
  { path: "/gaming", element: <GamingPC /> },
  { path: "/professional", element: <ProfessionalPC /> },
  { path: "/editing", element: <EditingPC /> },
  { path: "/gaming-container1", element: <GamingContainer1 /> },
  { path: "/gaming-container2", element: <GamingContainer2 /> },
  { path: "/prof-container1", element: <ProfContainer1 /> },
  { path: "/prof-container2", element: <ProfContainer2 /> },
];
