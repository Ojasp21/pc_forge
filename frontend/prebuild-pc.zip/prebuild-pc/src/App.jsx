import React from "react";
import { Route, Routes } from "react-router-dom";
import PrebuildPCPage from "./components/PreBuildPCPage";
import GamingPC from "./components/GamingPC";
import ProfessionalPC from "./components/ProfessionalPC";
import EditingPC from "./components/EditingPC";
import GamingContainer1 from "./components/containers/GamingContainer1";
import GamingContainer2 from "./components/containers/GamingContainer2";
import ProfContainer1 from "./components/containers/ProfContainer1";
import ProfContainer2 from "./components/containers/ProfContainer2";
import EditingContainer1 from "./components/containers/EditingComtainer1";
import EditingContainer2 from "./components/containers/EditingContainer2";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<PrebuildPCPage />} />
      <Route path="/gaming" element={<GamingPC />} />
      <Route path="/professional" element={<ProfessionalPC />} />
      <Route path="/editing" element={<EditingPC />} />
      <Route path="/gaming-container1" element={<GamingContainer1 />} />
      <Route path="/gaming-container2" element={<GamingContainer2 />} />
      <Route path="/prof-container2" element={<ProfContainer2/>}/>
      <Route path="/prof-container1" element={<ProfContainer1/>}/>
      <Route path="/editing-container1" element={<EditingContainer1/>}/>
      <Route path="/editing-container2" element={<EditingContainer2/>}/>
    </Routes>
  );
};

export default App;
