import React from "react";

const GamingContainer1 = () => {
  return (
    <div>
      <h1>High-Performance Gaming</h1>
      <p>Details about high-performance gaming PCs...</p>
    </div>
  );
};

export default GamingContainer1;
