import React from "react";

const ProfContainer2 = () => {
  return (
    <div>
      <h1>Professional PC for Office Use</h1>
      <p>Details about professional PCs optimized for office tasks, programming, and productivity applications.</p>
    </div>
  );
};

export default ProfContainer2;
