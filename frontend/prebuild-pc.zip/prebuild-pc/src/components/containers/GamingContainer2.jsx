import React from "react";

const GamingContainer2 = () => {
  return (
    <div>
      <h1>Budget-Friendly Gaming</h1>
      <p>Details about budget-friendly gaming PCs...</p>
    </div>
  );
};

export default GamingContainer2;
