import React from "react";

const ProfContainer1 = () => {
  return (
    <div>
      <h1>Professional PC for Workstations</h1>
      <p>Details about professional PCs designed for high-end workstations, ideal for graphic design, video editing, and 3D rendering.</p>
    </div>
  );
};

export default ProfContainer1;
